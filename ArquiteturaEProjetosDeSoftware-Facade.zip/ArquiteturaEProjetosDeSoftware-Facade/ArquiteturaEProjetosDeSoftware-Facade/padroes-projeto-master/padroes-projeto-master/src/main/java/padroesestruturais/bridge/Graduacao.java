package padroesestruturais.bridge;

public class Graduacao implements Escolaridade {

    public float percentualAumento() {
        return 0.1f;
    }
}
