package padroescriacao.abstractfactory;

public interface Diploma {

    String emitir();
}
