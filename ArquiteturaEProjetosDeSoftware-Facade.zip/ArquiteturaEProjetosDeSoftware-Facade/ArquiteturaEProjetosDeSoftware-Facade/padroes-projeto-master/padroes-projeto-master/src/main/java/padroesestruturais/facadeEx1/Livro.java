package padroesestruturais.facadeEx1;

public class Livro extends Produto {
    public Livro( String nome, double preco) {
        super(nome, preco);
    }

    @Override
    public void aplicarDesconto() {
        preco = preco * 0.9;
    }
}