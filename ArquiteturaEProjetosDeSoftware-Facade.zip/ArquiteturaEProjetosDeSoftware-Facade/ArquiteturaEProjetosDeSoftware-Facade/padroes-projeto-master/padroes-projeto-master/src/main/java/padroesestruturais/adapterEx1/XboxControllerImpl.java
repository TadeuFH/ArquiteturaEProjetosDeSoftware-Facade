package padroesestruturais.adapterEx1;

public class XboxControllerImpl implements XboxController {
    public String pressA() {
        return "Pressing A button on Xbox controller";
    }

    public String pressB() {
        return "Pressing B button on Xbox controller";
    }

    public String pressX() {
        return "Pressing X button on Xbox controller";
    }

    public String pressY() {
        return "Pressing Y button on Xbox controller";
    }
}
