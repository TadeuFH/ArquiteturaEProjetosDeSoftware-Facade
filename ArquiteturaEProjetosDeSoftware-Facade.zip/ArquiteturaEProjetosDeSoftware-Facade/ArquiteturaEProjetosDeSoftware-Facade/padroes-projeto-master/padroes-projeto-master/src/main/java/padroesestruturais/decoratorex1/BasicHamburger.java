package padroesestruturais.decoratorex1;

public class BasicHamburger implements Hamburger {
    public String getDescription() {
        return "Pão com carne";
    }

    public double getCost() {
        return 5.0;
    }
}
