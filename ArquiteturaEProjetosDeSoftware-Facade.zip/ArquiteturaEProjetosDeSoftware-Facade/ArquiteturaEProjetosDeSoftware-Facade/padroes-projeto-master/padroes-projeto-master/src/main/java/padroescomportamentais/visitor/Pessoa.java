package padroescomportamentais.visitor;

public interface Pessoa {
    String aceitar(Visitor visitor);
}
