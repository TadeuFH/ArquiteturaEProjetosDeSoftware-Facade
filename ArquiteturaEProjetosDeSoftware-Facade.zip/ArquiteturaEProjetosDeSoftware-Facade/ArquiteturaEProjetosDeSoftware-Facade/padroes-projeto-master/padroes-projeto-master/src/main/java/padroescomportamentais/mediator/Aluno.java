package padroescomportamentais.mediator;

public class Aluno extends Pessoa {
}
