package padroesestruturais.decoratorex1;

public class EggDecorator extends HamburgerDecorator {
    public EggDecorator(Hamburger hamburger) {
        super(hamburger);
    }

    public String getDescription() {
        return hamburger.getDescription() + ", ovo";
    }

    public double getCost() {
        return hamburger.getCost() + 1.0;
    }
}