package padroesestruturais.adapterEx1;

public class XboxPlayStationAdapter implements PlayStationController {
    private XboxController xboxController;

    public XboxPlayStationAdapter(XboxController xboxController) {
        this.xboxController = xboxController;
    }

    public String pressCross() {
        return xboxController.pressA();
    }

    public String pressCircle() {
        return xboxController.pressB();
    }

    public String pressSquare() {
        return xboxController.pressX();
    }

    public String pressTriangle() {
        return xboxController.pressY();
    }
}
