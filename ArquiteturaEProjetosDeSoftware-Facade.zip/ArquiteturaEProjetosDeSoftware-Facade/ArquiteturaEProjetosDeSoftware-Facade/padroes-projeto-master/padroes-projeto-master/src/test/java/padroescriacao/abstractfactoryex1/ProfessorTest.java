package padroescriacao.abstractfactoryex1;

import org.junit.jupiter.api.Test;
import padroescriacao.abstractfactory.Aluno;
import padroescriacao.abstractfactory.FabricaGraduacao;
import padroescriacao.abstractfactory.FabricaPosGraduacao;

import static org.junit.jupiter.api.Assertions.*;

public class ProfessorTest {

    @Test
    void deveEmitirNotaEnsinoMedio() {
        FabricaAbstrata fabrica = new FabricaEnsinoMedio();
        Professor professor = new Professor(fabrica);
        assertEquals("Nota de Ensino Medio", professor.emitirNota());
    }

    @Test
    void deveEmitirNotaEnsinoFundamental() {
        FabricaAbstrata fabrica = new FabricaEnsinoFundamental();
        Professor professor = new Professor(fabrica);
        assertEquals("Nota de Ensino Fundamental", professor.emitirNota());
    }

    @Test
    void deveEmitirDisciplinaEnsinoMedio() {
        FabricaAbstrata fabrica = new FabricaEnsinoMedio();
        Professor professor = new Professor(fabrica);
        assertEquals("Disciplina Ensino Medio", professor.emitirDisciplina());
    }

    @Test
    void deveEmitirDisciplinaEnsinoFundamental() {
        FabricaAbstrata fabrica = new FabricaEnsinoFundamental();
        Professor professor = new Professor(fabrica);
        assertEquals("Disciplina Ensino Fundamental", professor.emitirDisciplina());
    }




}
