package padroesestruturais.adapterEx1;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

public class ControllerAdapterTest {
    @Test
    public void testXboxPlayStationAdapter() {
        XboxController xboxController = new XboxControllerImpl();
        XboxPlayStationAdapter adapter = new XboxPlayStationAdapter(xboxController);

        assertEquals("Pressing A button on Xbox controller", xboxController.pressA());
        assertEquals("Pressing B button on Xbox controller", xboxController.pressB());
        assertEquals("Pressing X button on Xbox controller", xboxController.pressX());
        assertEquals("Pressing Y button on Xbox controller", xboxController.pressY());

        assertEquals("Pressing A button on Xbox controller", adapter.pressCross());
        assertEquals("Pressing B button on Xbox controller", adapter.pressCircle());
        assertEquals("Pressing X button on Xbox controller", adapter.pressSquare());
        assertEquals("Pressing Y button on Xbox controller", adapter.pressTriangle());
    }

    @Test
    public void testPlayStationXboxAdapter() {
        PlayStationController playStationController = new PlayStationControllerImpl();
        PlayStationXboxAdapter adapter = new PlayStationXboxAdapter(playStationController);

        assertEquals("Pressing Cross button on PlayStation controller", playStationController.pressCross());
        assertEquals("Pressing Circle button on PlayStation controller", playStationController.pressCircle());
        assertEquals("Pressing Square button on PlayStation controller", playStationController.pressSquare());
        assertEquals("Pressing Triangle button on PlayStation controller", playStationController.pressTriangle());

        assertEquals("Pressing Cross button on PlayStation controller", adapter.pressA());
        assertEquals("Pressing Circle button on PlayStation controller", adapter.pressB());
        assertEquals("Pressing Square button on PlayStation controller", adapter.pressX());
        assertEquals("Pressing Triangle button on PlayStation controller", adapter.pressY());
    }

    @Test
    public void NotEqualsTestPlayStationXboxAdapter() {
        PlayStationController playStationController = new PlayStationControllerImpl();
        PlayStationXboxAdapter adapter = new PlayStationXboxAdapter(playStationController);
        assertNotEquals("Pressing Cross button on PlayStation controller", playStationController.pressSquare());
        assertEquals("Pressing Cross button on PlayStation controller", playStationController.pressCross());
    }
}
