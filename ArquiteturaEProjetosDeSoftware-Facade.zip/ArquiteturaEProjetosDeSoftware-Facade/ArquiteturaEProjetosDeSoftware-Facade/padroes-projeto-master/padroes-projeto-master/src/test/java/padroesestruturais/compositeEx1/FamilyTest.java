package padroesestruturais.compositeEx1;

import org.junit.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;

public class FamilyTest {

    @Test
    public void testFamilyHasNoParents() {
        Family family = new Family("Doe");

        List<Person> parents = family.getParents();
        assertEquals(parents.size(), 0);
    }

    @Test
    public void testAddAndRemoveChild() {
        Family parent = new Family("Doe");
        Individual child1 = new Individual("John Doe", 10);
        Individual child2 = new Individual("Jane Doe", 8);

        parent.addChild(child1);
        parent.addChild(child2);

        List<Person> children = parent.getChildren();
        assertEquals(children.size(), 2);
        assertTrue(children.contains(child1));
        assertTrue(children.contains(child2));

        parent.removeChild(child1);
        children = parent.getChildren();
        assertEquals(children.size(), 1);
        assertFalse(children.contains(child1));
        assertTrue(children.contains(child2));
    }
}