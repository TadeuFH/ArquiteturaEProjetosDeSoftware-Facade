package padroesestruturais.facadeEx1;

import org.junit.Assert;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LojasTest {
    @Test
    public void testListarProdutoss() {
        Livro livro = new Livro("Livro 1", 10.0);
        Eletronico eletronico = new Eletronico("Eletronico 1", 20.0);
        Loja loja = new Loja(Arrays.asList(livro, eletronico));
        assertEquals(Arrays.asList(livro, eletronico), loja.listarProdutos());
    }

    @Test
    public void testListarProdutos() {
        List<Produto> produtos = new ArrayList<>();
        produtos.add(new Livro("Dom Casmurro", 25.0));
        produtos.add(new Eletronico("iPhone 13", 5000.0));
        Loja loja = new Loja(produtos);
        List<Produto> produtosListados = loja.listarProdutos();
        Assert.assertEquals(2, produtosListados.size());
        Assert.assertTrue(produtosListados.get(0) instanceof Livro);
        Assert.assertTrue(produtosListados.get(1) instanceof Eletronico);
    }

    @Test
    public void testeListarProdutos() {
        List<Produto> produtos = new ArrayList<>();
        produtos.add(new Livro("Livro 1", 100.0));
        produtos.add(new Eletronico("Eletronico 1", 200.0));
        Loja loja = new Loja(produtos);

        List<Produto> produtosNaLoja = loja.listarProdutos();
        assertEquals(2, produtosNaLoja.size());
        assertEquals("Livro 1", produtosNaLoja.get(0).getNome());
        assertEquals("Eletronico 1", produtosNaLoja.get(1).getNome());
    }



    @Test
    public void testCalcularPrecoProduto() {
        Livro livro = new Livro("Livro 1", 10.0);
        Eletronico eletronico = new Eletronico("Eletronico 1", 20.0);
        Loja loja = new Loja(Arrays.asList(livro, eletronico));
        assertEquals(9.0, loja.calcularPrecoProduto(livro), 0.001);
        assertEquals(16.0, loja.calcularPrecoProduto(eletronico), 0.001);
    }
}
